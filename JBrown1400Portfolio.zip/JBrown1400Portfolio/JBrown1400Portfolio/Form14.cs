﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form14 : Form
    {
        private Random ObjR = new Random();
        public Form14()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int var1;
            int var2;
            try
            {
                //Make boxes same size
                textBox2.Width = textBox1.Width;
                textBox2.Height = textBox1.Height;
                //Assign input representing x coordinates to variables
                var1 = Convert.ToInt32(textBox1.Text);
                var2 = Convert.ToInt32(textBox2.Text);
                //Move right
                textBox1.Left = var1;
                textBox2.Left = var2;
                if ((var1 + textBox1.Width) >= pictureBox1.Left)
                // Box 1 crosses finish line
                {
                    if (textBox1.Left > textBox2.Left)
                    {
                        MessageBox.Show("textBox1 wins");
                    }
                }
                if ((var2 + textBox2.Width) >= pictureBox1.Left)
                // Box 1 crosses finish line
                {
                    if (textBox2.Left > textBox1.Left)
                    {
                        MessageBox.Show("textBox2 wins");
                    }
                }
                if (var1 + textBox1.Left == var2 + textBox2.Left)
                {
                    if (var1 + textBox1.Left > pictureBox1.Left)
                    {
                        MessageBox.Show("Tie");
                    }
                }
            }
            catch { }
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            this.Text = pictureBox1.Left.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //Allows boxes to move based on timer
            int var1 = Convert.ToInt32(textBox1.Text);
            int var2 = Convert.ToInt32(textBox2.Text);

            var1 = ObjR.Next();
            var2 = ObjR.Next();

            textBox1.Left = var1;
            textBox2.Left = var2;

            textBox1.Text = var1.ToString();
            textBox2.Text = var2.ToString();

            if ((textBox1.Left > pictureBox1.Left)|| (textBox2.Left > pictureBox1.Left))
            {
                timer1.Enabled = false;
                pictureBox1.Enabled = false;
            }


        }
    }
}
