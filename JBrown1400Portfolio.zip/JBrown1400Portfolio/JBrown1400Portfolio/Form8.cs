﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 NextForm = new Form6();
            NextForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form9 NextForm = new Form9();
            NextForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form10 NextForm = new Form10();
            NextForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form11 NextForm = new Form11();
            NextForm.Show();
        }
    }
}
