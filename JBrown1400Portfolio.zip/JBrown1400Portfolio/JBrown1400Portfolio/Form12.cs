﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form12 : Form
    {
        private Random ObjR = new Random();
        int num;
        int roll;
        int var1;
        public Form12()
        {
            InitializeComponent();
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            //buttons should deactivate when all boxes disappear
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Generate random number
            var1 = ObjR.Next(1, 7);
            textBox1.Text = Convert.ToString(var1);
            //Add to total roll
            num++;
            textBox2.Text = Convert.ToString(num);
            //deactivate itself and activate go
            button1.Enabled = false;
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int myNum = Convert.ToInt32(var1);
            //make picture boxes disapear
            if (myNum == 1)
            {
                pictureBox1.Visible = false;
                roll++;
            }
            if (myNum == 2)
            {
                pictureBox2.Visible = false;
                roll++;
            }
            if (myNum == 3)
            {
                pictureBox3.Visible = false;
                roll++;
            }
            if (myNum == 4)
            {
                pictureBox4.Visible = false;
                roll++;
            }
            if (myNum == 5)
            {
                pictureBox5.Visible = false;
                roll++;
            }
            if (myNum == 6)
            {
                pictureBox6.Visible = false;
                roll++;

            }
            textBox3.Text = Convert.ToString(num);
            //deactivate itself and activate roll
            button1.Enabled = true;
            button2.Enabled = false;
        }
    }
}
