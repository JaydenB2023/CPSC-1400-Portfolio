﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form22 : Form
    {
        string dt = DateTime.Now.ToString();
        public Form22()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show(dt.Substring(dt.Length - 2, 2));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string myDate = "";
            int i = 0;
            while (dt.Substring(i, 1)!= "")
            {
                myDate = myDate + dt.Substring(i, 1);
                i++;
            }
            MessageBox.Show(myDate);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string myYear = "";
            int i = 6;
            while (dt.Substring(i, 1)!= "")
            {
                myYear = myYear + dt.Substring(i, 1);
                i++;
            }
            MessageBox.Show(myYear);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string myTime = "";
            int i = 10;
            while (dt.Substring(i, 1) != "")
            {
                myTime = myTime + dt.Substring(i, 1);
                i++;
            }
            MessageBox.Show(myTime);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string mil = "";
            int hour = 12;
            int i = 10;
            while (dt.Substring(dt.Length -2, 2) == "A")
            {
                mil = mil + dt.Substring(i, 10);
                i++;
            }
            MessageBox.Show(mil);
            while (dt.Substring(dt.Length -2, 2) == "P")
            {
                mil = hour + dt.Substring(i, 2);
                i++;
            }
            MessageBox.Show(mil);

        }
    }
}
