﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form24 : Form
    {
        string curdate = DateTime.Now.ToString("tt");
        public Form24()
        {
            InitializeComponent();
        }

        private void Form24_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Marquee();
            Time12();
            Time24();
            Date();
            Sun();
            ConversionBase();
        }

        private void Time12()
        {
            string hr = DateTime.Now.ToString("hh:mm:ss");
            label2.Text = hr.ToString();
        }
        private void Time24()
        {
            string mil = DateTime.Now.ToString("HH:mm:ss");
            label3.Text = mil.ToString();
        }
        private void Date()
        {
            string day = DateTime.Now.ToString("MMM dd yyyy");
            label4.Text = day.ToString();
        }
        private void Marquee()
        {
            string firstletter = label1.Text.Substring(0, 1);
            string starttext = label1.Text.Substring(1, label1.Text.Length - 1);

            string finalstring = starttext + firstletter;

            label1.Text = finalstring;
        }
        private void Sun()
        {
            if (curdate.Substring(0,2) == "AM")
            {
                pictureBox1.Image = Image.FromFile("sun.jpg");
            }
            else
            {
                pictureBox1.Image = Image.FromFile("moon.jpg");
            }
        }
        private void ConversionBase()
        {
            string hr = DateTime.Now.ToString("HH");
            string min = DateTime.Now.ToString("mm");
            int dividend = Convert.ToInt32(hr);
            int dividend2 = Convert.ToInt32(min);
            string result = "";
            int rem;
            while (dividend != 0)
            {
                rem = dividend % 2;
                dividend /= 2;
                result = rem.ToString() + result;
            }
            label5.Text = result;
            while (dividend2 != 0)
            {
                rem = dividend2 % 2;
                dividend2 /= 2;
                result = rem.ToString() + result;
            }
            label6.Text = result;
        }

    }
}
