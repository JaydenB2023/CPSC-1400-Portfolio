﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form5 : Form
    {
        Double equals;
        public Form5()
        {
            InitializeComponent();
        }
        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string result = "";
            if (comboBox1.SelectedText == "1")
            {
                result = textBox1.Text.Substring(1, textBox1.Text.Length + 1);
            }
            if (comboBox1.SelectedText == "2")
            {
                result = textBox1.Text.Substring(1, textBox1.Text.Length + 2);
            }
            if (comboBox1.SelectedText == "3")
            {
                result = textBox1.Text.Substring(1, textBox1.Text.Length + 3);
            }
            this.Text = result;


        }

        private void button2_Click(object sender, EventArgs e)
        {
            double startval = Convert.ToDouble(textBox1.Text);
            equals = Math.Round(startval);
            this.Text = Convert.ToString(equals);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            this.Text = "";
        }
    }
}
