﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form10 : Form
    {
        private Random ObjR = new Random();
        private int Tot = 0;
        public Form10()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int CurNum = ObjR.Next(1, 8);
            int CurNum1 = ObjR.Next(1, 8);
            label3.Text = CurNum.ToString();
            label4.Text = CurNum1.ToString();
            Tot = CurNum1 * CurNum;
            label5.Text = "Tot =" + Tot.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label5.BackColor = Color.White;
        }
    }
}
