﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form19 : Form
    {
        private Random ObjR = new Random();
        private int Tot = 0;
        int numer;
        int den;
        public Form19()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //generate random numbers
            int CurNum = ObjR.Next(1, 101);
            int CurNum1 = ObjR.Next(1, 101);
            label3.Text = CurNum.ToString();
            label4.Text = CurNum1.ToString();
            Tot = CurNum1 * CurNum;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = Tot.ToString();
            //change label1 percentage and check correction
            if (textBox3.Text == textBox1.Text)
            {
                numer++;
                den++;
                int Total = numer % den;
                this.Text = Total.ToString() + "%";

            }
            else
            {
                den++;
                int Total = numer % den;
                this.Text = Total.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //reset everything except percentage
            label3.Text = "";
            label4.Text = "";
            textBox3.Text = "";
            textBox1.Text = "";
        }
    }
}
