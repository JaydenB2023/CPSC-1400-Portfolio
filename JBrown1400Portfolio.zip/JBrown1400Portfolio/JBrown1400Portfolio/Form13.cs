﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form13 : Form
    {
        private Random ObjR = new Random();
        int numb = 0;
        int box = 6;
        public Form13()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //replace picture boxes
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            pictureBox4.Visible = true;
            pictureBox5.Visible = true;
            pictureBox6.Visible = true;
            //reset current roll value and boxes remaining
            textBox1.Text = "";
            textBox3.Text = "";
            this.Text = "";
        }

        private void Form13_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            //roll value
            int var1 = ObjR.Next(1, 7);
            int var2 = 6 % var1;
            int var3 = Convert.ToInt32(var2);
            //make picture boxes disappear
            if (var3 == 1)
            {
                pictureBox1.Visible = false;
                box--;
            }
            if (var3 == 2)
            {
                pictureBox2.Visible = false;
                box--;
            }
            if (var3 == 3)
            {
                pictureBox3.Visible = false;
            }
            if (var3 == 4)
            {
                pictureBox4.Visible = false;
                box--;
            }
            if (var3 == 5)
            {
                pictureBox5.Visible = false;
                box--;
            }
            if (var3 == 6)
            {
                pictureBox6.Visible = false;
                box--;

            }
            //fill in text boxes
            textBox1.Text = Convert.ToString(var2);
            textBox3.Text = Convert.ToString(box);
            //add to total roll
            numb++;
            this.Text = numb.ToString();
        }
    }
    
}
