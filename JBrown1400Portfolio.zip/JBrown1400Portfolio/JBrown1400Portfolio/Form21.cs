﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JBrown1400Portfolio
{
    public partial class Form21 : Form
    {
        public Form21()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form17 NextForm = new Form17();
            NextForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form19 NextForm = new Form19();
            NextForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form18 NextForm = new Form18();
            NextForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form20 NextForm = new Form20();
            NextForm.Show();
        }
    }
}
